import React, { createContext } from 'react'

export const AttendanceContext = createContext();